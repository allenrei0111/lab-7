﻿using BasicMath1;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicMathTests
{
    [TestClass]
    public class BasicMathTests
    {
        [TestMethod]
        public void TestAdd()
        {
            BasicMath math = new BasicMath();
            double result = math.Add(2.0, 3.0);
            Assert.AreEqual(5.0, result);
        }

        [TestMethod]
        public void TestSubtract()
        {
            BasicMath math = new BasicMath();
            double result = math.Subtract(3.0, 2.0);
            Assert.AreEqual(1.0, result);
        }

        [TestMethod]
        public void TestMultiply()
        {
            BasicMath math = new BasicMath();
            double result = math.Multiply(2.0, 3.0);
            Assert.AreEqual(6.0, result);
        }

        [TestMethod]
        public void TestDivide()
        {
            BasicMath math = new BasicMath();
            double result = math.Divide(6.0, 3.0);
            Assert.AreEqual(2.0, result);
        }

        [TestMethod]
        public void TestDivideByZero()
        {
            BasicMath math = new BasicMath();
            double result;
            try
            {
                result = math.Divide(10, 0);
            }
            catch (ArgumentException ex)
            {
                StringAssert.Contains(ex.Message, "Cannot divide by zero");
                return;
            }
            Assert.Fail("Expected exception was not thrown.");
        }
    }
}
