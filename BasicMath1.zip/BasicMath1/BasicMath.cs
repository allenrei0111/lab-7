﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicMath1
{
    public class BasicMath
    {
        public double Add(double a, double b)
        {
            return a + b;
        }

        public double Subtract(double a, double b)
        {
            return a - b;
        }

        public double Multiply(double a, double b)
        {
            return a * b;
        }

        public double Divide(double a, double b)
        {
            if (b == 0)
            {
                throw new ArgumentException("Cannot divide by zero");
            }
            return a / b;
        }

        static void Main(string[] args)
        {
            // Here you can write code to test your methods
            BasicMath math = new BasicMath();
            Console.WriteLine(math.Add(2, 3));
            Console.WriteLine(math.Subtract(5, 3));
            Console.WriteLine(math.Multiply(2, 3));
            Console.WriteLine(math.Divide(10, 5));
        }
    }
}
